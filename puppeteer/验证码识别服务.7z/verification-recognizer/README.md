# verification-recognizer
QQ登陆滑块验证识别
